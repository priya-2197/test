<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <!-- include common styles -->
      <?php include 'common_css.php';?>
      <!-- include common styles :end-->
      <title>Login | Healthcare App</title>
   </head>
   <body>

      <!-- section: login signup -->
      <section class="login-signup">
         <div class="container">
          <div class="content">
            <div class="form-box">
               <div class="row">
               <div class="col-lg-6 col-md-12 pe-lg-0">
                        <div class="image-panel"></div>
                  </div>
                  <div class="col-lg-6 col-md-12 ps-lg-0">
                        <div class="form-panel">
                        
                           <!-- login form -->
                          <div class="inner" id="formLogin">
                              <div class="logo-main">
                              <img class="logo"src="images/logo.png" alt="logo">
                              </div>
                              <div class="title-main">
                                 <h2 class="title">Login to your account</h2>
                                 <h4 class="sub-title">Welcome back! Select method to login:</h4>
                              </div>
                              <div class="social-login">
                                 <div class="row">
                                    <div class="col-md-6">
                                       <button class="btn btn-primary btn-social-login w-100"><i class="fa-brands fa-google me-2"></i>Google</button>
                                    </div>
                                    <div class="col-md-6">
                                       <button class="btn btn-primary btn-social-login w-100"><i class="fa-brands fa-facebook me-2"></i>Facebook</button>
                                    </div>
                                 </div>
                              </div>
                              <div class="separate">
                                 <p class="sep-title">Or continue with email</p>
                              </div>
                              <div class="form-content">
                              <form class="row g-3 needs-validation" novalidate>
                                 <div class="col-md-12">
                                    <label for="validationCustomEmail" class="form-label">Email</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-envelope"></i></span>
                                       <input type="email" class="form-control" id="validationCustomEmail"  placeholder="Enter your email" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter your email address.
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <label for="validationCustomPassword" class="form-label">Password</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-key"></i></span>
                                       <input type="password" class="form-control" id="validationCustomPassword"  placeholder="Enter your password" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter a valid password.
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-12">
                                    <div class="ext-options">
                                       <div class="row">
                                          <div class="col-6">
                                          <div class="form-check">
                                             <input class="form-check-input" type="checkbox" value="" id="rememberME">
                                             <label class="form-check-label" for="rememberME">
                                                Remember me
                                             </label>
                                             </div>
                                          </div>
                                          <div class="col-6 text-end">
                                             <a href="#" class="fp-link">Forgot Password?</a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-12 ">
                                    <button class="btn btn-primary btn-auth" type="submit">Login</button>
                                 </div>
                                 </form>
                                 <div class="after-form text-center">
                                       <p>Don't have an account? <a href="#" id="goToSign">Create an account</a></p>
                                 </div>
                              </div>
                           </div>
                            <!-- login form:end -->



                           <!-- signup form -->
                          <div class="inner" id="formSignUp" style="display:none">
                              <div class="logo-main">
                              <img src="images/logo.png" alt="logo">
                              </div>
                              <div class="title-main">
                                 <h2 class="title">Get Started with HealthApp</h2>
                                 <h4 class="sub-title">Create your account to get start with HealthApp.</h4>
                              </div>
      
                              <div class="form-content">
                              <form class="row g-3 needs-validation" novalidate>
                              <div class="col-md-12">
                                    <label for="validationCustomFname" class="form-label">First Name</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-user"></i></span>
                                       <input type="text" class="form-control" id="validationCustomFname"  placeholder="Enter your first name" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter your first name.
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <label for="validationCustomLname" class="form-label">Last Name</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-user"></i></span>
                                       <input type="text" class="form-control" id="validationCustomLname"  placeholder="Enter your last name" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter your last name.
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <label for="validationCustomEmailSign" class="form-label">Email</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-envelope"></i></span>
                                       <input type="email" class="form-control" id="validationCustomEmailSign"  placeholder="Enter your email" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter your email address.
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12">
                                    <label for="validationCustomPasswordSign" class="form-label">Password</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-key"></i></span>
                                       <input type="password" class="form-control" id="validationCustomPasswordSign"  placeholder="Enter your password" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please enter a valid password.
                                       </div>
                                    </div>
                                 </div>

                                 <div class="col-md-12">
                                    <label for="validationCustomPasswordConSign" class="form-label">Confirm Password</label>
                                    <div class="input-group has-validation">
                                       <span class="input-group-text" id="inputGroupPrepend"><i class="fa-solid fa-key"></i></span>
                                       <input type="password" class="form-control" id="validationCustomPasswordConSign"  placeholder="Re-enter password" aria-describedby="inputGroupPrepend" required>
                                       <div class="invalid-feedback">
                                       Please re-enter the password.
                                       </div>
                                    </div>
                                 </div>
         
                                 <div class="col-12 ">
                                    <button class="btn btn-primary btn-auth" type="submit">Signup</button>
                                 </div>
                                 </form>
                                 <div class="after-form text-center">
                                       <p>Already have an account? <a href="#" id="backToLog">Go back to login page</a></p>
                                 </div>
                              </div>
                           </div>
                            <!-- signup form:end -->


                        </div>
                  </div>
               </div>
            </div>
          </div>
         </div>
      </section>
      <!-- section: login signup:end -->
      

      <!-- include common js -->
      <?php include 'common_js.php';?>
      <!-- include common js :end-->


      <!-- scrips for form validation -->
      <script>
         (() => {
         'use strict'
         const forms = document.querySelectorAll('.needs-validation')
         Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
               if (!form.checkValidity()) {
               event.preventDefault()
               event.stopPropagation()
               }

               form.classList.add('was-validated')
            }, false)
         })
         })()
      </script>

      <!-- script for toggle login and signup forms -->
      <script>
         $(document).ready(function(){
         $("#goToSign").click(function(){
         $("#formSignUp").show();
         $("#formLogin").hide();
         });
         $("#backToLog").click(function(){
         $("#formSignUp").hide();
         $("#formLogin").show();
         });
         });
      </script> 

   </body>
</html>