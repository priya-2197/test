<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <!-- include common styles -->
      <?php include 'common_css.php';?>
      <!-- include common styles :end-->
      <!-- date-rangepicker -->
      <link href="css/daterangepicker.css" rel="stylesheet" />
      <title>User Details | Healthcare App</title>
   </head>
   <body>

      <!-- User details -->
      <div class="user-details">
         <div class="container">
                  <!-- basic user information -->
                  <section class="user-basics section-padding">
                        <div class="content">
                           <h2 class="title-common">Basic Information</h2>
                           <div class="row">
                              <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                                    <div class="card mn-over-mob">
                                       <div class="card-body">
                                          <div class="user-thumb-holder">
                                             <img src="images/img-user-thumb.webp" class="user-thumb" alt="User Image">
                                          </div>
                                          <div class="user-info">
                                             <h4 class="name">Jennifer Kelly</h4>
                                             <p class="email">jeniferkelly004@gmail.com</p>
                                          </div>
                                          <div class="user-stat">
                                             <div class="row">
                                                <div class="col-md-4 pe-md-1">
                                                   <div class="stat-box">
                                                      <h4 class="title">92<span>Kg</span></h4>
                                                      <p class="sub-title">Weight<span class="lvl-common text-success down-lvl"><i class="fa-solid fa-caret-down"></i>10</span></p>
                                                   </div>
                                                </div>
                                                <div class="col-md-4 ps-md-1 pe-md-1">
                                                   <div class="stat-box">
                                                      <h4 class="title">175<span>Cm</span></h4>
                                                      <p class="sub-title">Height</p>
                                                   </div>
                                                </div>
                                                <div class="col-md-4 ps-md-1">
                                                   <div class="stat-box">
                                                      <h4 class="title">124/80</h4>
                                                      <p class="sub-title">BP<span class="lvl-common text-danger up-lvl"><i class="fa-solid fa-caret-up"></i>10</span></p>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                              </div>
                              <div class="col-lg-8 col-md-12">
                                    <div class="card mn-over-mob">
                                       <div class="card-body">
                                          <div class="details-view">
                                             <div class="row">
                                                <div class="col-md-3">
                                                   <label class="label">First Name</label>
                                                   <p class="info">Jennifer</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Last Name</label>
                                                   <p class="info">Kelly</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">DOB</label>
                                                   <p class="info">20/08/1993</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Gender</label>
                                                   <p class="info">Female</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Age</label>
                                                   <p class="info">25</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Phone</label>
                                                   <p class="info">31 452563</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Mobile</label>
                                                   <p class="info">97 4455 3221</p>
                                                </div>
                                                <div class="col-md-3">
                                                   <label class="label">Profession</label>
                                                   <p class="info">IT Professional</p>
                                                </div>
                                             </div>
                                             <div class="row">
                                                <div class="col-md-9">
                                                <label class="label">Address</label>
                                                   <p class="info">Carnival Infopark Phase I, Infopark Park Centre, near Thapasya, Kakkanad, Kochi, Kerala 682042</p>
                                                </div>
                                                <div class="col-md-3">
                                                <label class="label">Email</label>
                                                   <p class="info">janniferkelly004@gmail.com</p>
                                                </div>
                                             </div>
                                             <div class="row">
                                                <div class="col-12 text-end">
                                                   <button class="btn btn-primary btn-edit-info" data-bs-toggle="modal" data-bs-target="#modalEditUserInfo"><i class="fa-regular fa-pen-to-square me-2"></i>Edit</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                             </div>
                           </div>
                        </div>
                  </section>
                  <!-- basic user information:end -->


                  <!-- user stat -->
                  <section class="user-statics section-padding">
                     <div class="content">
                     <h2 class="title-common">Current Statics</h2>
                     <div class="row">
                        <div class="col-lg-3 col-md-6">
                           <div class="card opt-01">
                              <div class="card-body">
                                 <div class="stat-ico-holder">
                                    <div class="bg-ico_diag_01"></div>
                                 </div>
                                 <h2 class="title">Blood Pressure</h2>
                                 <p class="perc">30%</p>
                                 <p class="val">141/90 mmhg</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                           <div class="card opt-02">
                              <div class="card-body">
                                 <div class="stat-ico-holder">
                                    <div class="bg-ico_diag_02"></div>
                                 </div>
                                 <h2 class="title">Body Temperature</h2>
                                 <p class="perc">10%</p>
                                 <p class="val">37C</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                           <div class="card opt-03">
                              <div class="card-body">
                                 <div class="stat-ico-holder">
                                    <div class="bg-ico_diag_03"></div>
                                 </div>
                                 <h2 class="title">Body Weight</h2>
                                 <p class="perc">20%</p>
                                 <p class="val">80kg</p>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                           <div class="card opt-04">
                              <div class="card-body">
                                 <div class="stat-ico-holder">
                                    <div class="bg-ico_diag_04"></div>
                                 </div>
                                 <h2 class="title">Body Glucose</h2>
                                 <p class="perc">40%</p>
                                 <p class="val">140 mg/dl</p>
                              </div>
                           </div>
                        </div>
                     </div>
                     </div>
                  </section>
                  <!-- user stat:end -->

                  <!-- diagnosis chart -->
                  <section class="stat-chart section-padding">
                     <div class="content">
                        <div class="row">
                           <div class="col-md-8">
                           <h2 class="title-common">Blood Pressure</h2>
                           <div class="card crt-over-mob mb-4 mb-md-0">
                              <div class="card-body">
                              <div id="linechart_material"></div>
                              </div>
                           </div>
                           </div>
                           <div class="col-md-4">
                           <h2 class="title-common">Diagnosis</h2>
                           <div class="card crt-over-mob">
                              <div class="card-body">
                              <div id="myPieChart"></div>
                              </div>
                           </div>
                           </div>
                           </div>
                     </div>
                  </section>
                  <!-- diagnosis chart:end -->
         </div>
      </div>
      <!-- User details:end -->
      

      <!-- Modal: Edit user details -->
      <div class="modal fade" id="modalEditUserInfo" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Details</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form class="g-3 needs-validation" novalidate>
            <div class="modal-body">
            <div class="row">
            <div class="col-md-4 mb-3">
                  <label for="validationCustomFname" class="form-label">First Name</label>
                  <input type="text" class="form-control" id="validationCustomFname" value="Jennifer" required>
                     <div class="invalid-feedback">
                     Please enter your first name.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomLname" class="form-label">First Name</label>
                  <input type="text" class="form-control" id="validationCustomLname" value="Kelly" required>
                     <div class="invalid-feedback">
                     Please enter your last name.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="dob-pick" class="form-label">DOB</label>
                  <input type="text" class="form-control" id="dob-pick" value="08/20/93" required>
                     <div class="invalid-feedback">
                     Please choose a valid date.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomGen" class="form-label">Gender</label>
                  <input type="text" class="form-control" id="validationCustomGen" value="Female" required>
                     <div class="invalid-feedback">
                     Please Enter your gender.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomAge" class="form-label">Age</label>
                  <input type="text" class="form-control" id="validationCustomAge" value="25" required>
                     <div class="invalid-feedback">
                     Please Enter your age.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomPhone" class="form-label">Phone</label>
                  <input type="text" class="form-control" id="validationCustomPhone" value="31 452563" required>
                     <div class="invalid-feedback">
                     Please Enter your phone number.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomMobile" class="form-label">Mobile</label>
                  <input type="text" class="form-control" id="validationCustomMobile" value="97 4455 3221" required>
                     <div class="invalid-feedback">
                     Please Enter your mobile number.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomProf" class="form-label">Profession</label>
                  <input type="text" class="form-control" id="validationCustomProf" value="IT Professional" required>
                     <div class="invalid-feedback">
                     Please Enter your profession.
                     </div>
               </div>
               <div class="col-md-8 mb-3">
                  <label for="validationCustomAddr" class="form-label">Address</label>
                  <input type="text" class="form-control" id="validationCustomAddr" value="Carnival Infopark Phase I, Infopark Park Centre, near Thapasya, Kakkanad, Kochi, Kerala 682042" required>
                     <div class="invalid-feedback">
                     Please Enter your address.
                     </div>
               </div>
               <div class="col-md-4 mb-3">
                  <label for="validationCustomEmail" class="form-label">Email</label>
                  <input type="text" class="form-control" id="validationCustomEmail" value="janniferkelly004@gmail.com" required>
                     <div class="invalid-feedback">
                     Please Enter your email.
                     </div>
               </div>
            </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
           </form>
         </div>
      </div>
      </div>
      <!-- Modal: Edit user details:end -->


      <!-- include common js -->
      <?php include 'common_js.php';?>
      <!-- include common js :end-->

      <!-- date-range-picker -->
      <script src="js/moment.min.js"></script>
      <script src="js/daterangepicker.js"></script>

      <script>
      $(function() {
      $('#dob-pick').daterangepicker({
         singleDatePicker: true,
         showDropdowns: true,
         minYear: 1901,
         maxYear: parseInt(moment().format('YYYY'),10)
      }, function(start, end, label) {
         var years = moment().diff(start, 'years');
      });
      });
      </script>

      <script src="https://www.gstatic.com/charts/loader.js"></script>
      <script>
    google.charts.load('current', {packages: ['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
      // Define the chart to be drawn.
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Element');
      data.addColumn('number', 'Percentage');
      data.addRows([
        ['Glucose', 0.78],
        ['Temperature', 0.18],
        ['Pressure', 0.12]
      ]);

      // Instantiate and draw the chart.
      var chart = new google.visualization.PieChart(document.getElementById('myPieChart'));
      chart.draw(data, null);
    }
  </script>

  <script>
   google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = new google.visualization.DataTable();
      data.addColumn('number', 'Day');
      data.addColumn('number', 'Bood Pressure');

      data.addRows([
        [1,  40.8],
        [2,  32.4],
        [3,  90.8],

      ]);

      var options = {
        height: 250
      };

      var chart = new google.charts.Line(document.getElementById('linechart_material'));

      chart.draw(data, google.charts.Line.convertOptions(options));
    }
  </script>

      <!-- scrips for form validation -->
      <script>
         (() => {
         'use strict'
         const forms = document.querySelectorAll('.needs-validation')
         Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
               if (!form.checkValidity()) {
               event.preventDefault()
               event.stopPropagation()
               }

               form.classList.add('was-validated')
            }, false)
         })
         })()
      </script>

 

   </body>
</html>